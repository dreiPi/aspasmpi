AspAsmPi
========

AspSymProg Assembler-Projekt fuer Gruppe "&pi;": Moritz Mackiewicz, Elias Marquart, Claus Strasburger

Projektaufgabe: 1.77 --- Berechnung der Kapazität eines Kugelkondensators

[Präsentation](https://docs.google.com/presentation/d/11IB34kHI3xgEe9zkwt7QF_9oDpvaE-RPHbbh9b04_GM/edit?usp=sharing)

[Dokumentation](Dokumentation/Ausarbeitung.tex)

Timings [Galaxy S3, -O0](galaxys3O0.txt)
